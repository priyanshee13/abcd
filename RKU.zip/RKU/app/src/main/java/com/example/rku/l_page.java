package com.example.rku;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.ImageButton;

public class l_page extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lpage);
        getSupportActionBar().setTitle(Html.fromHtml("<font color=\"black\">" + getString(R.string.l_page)+ "</font>"));

        ImageButton img1=(ImageButton) findViewById(R.id.imageButton);
        ImageButton img2=(ImageButton) findViewById(R.id.imageButton2);
        ImageButton img3=(ImageButton) findViewById(R.id.imageButton3);

        img1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i1 = new Intent(Intent.ACTION_DIAL,Uri.parse("tel:9712489122"));
                startActivity(i1);
            }
        });

        img2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String url = "http://rku.ac.in/";
                Intent i2 = new Intent(Intent.ACTION_VIEW,Uri.parse(url));
                startActivity(i2);
            }
        });

        img3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i3 = new Intent(Intent.ACTION_SEND);
                i3.setType("text/plain");
                startActivity(i3);
            }
        });
    }

}