package com.example.rku;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class f_page extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fpage);
        getSupportActionBar().setTitle(Html.fromHtml("<font color=\"black\">" + getString(R.string.f_page)+ "</font>"));
        Button btn = (Button) findViewById(R.id.button);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(f_page.this,s_page.class);
                startActivity(intent);
            }
        });
    }

    int counter=0;
    //back method
    public void onBackPressed() {
        counter++;
        if (counter == 2){
            super.onBackPressed();
        }else {
            Toast.makeText(this, "Press back again to exit", Toast.LENGTH_SHORT).show();
        }
    }

}